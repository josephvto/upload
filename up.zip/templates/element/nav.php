<ul class="navbar-nav">

<li class="nav-item">
  <a class="nav-link " href="<?php echo BASE; ?>">Home</a>
</li>

<li class="nav-item">
  <a class="nav-link " href="<?php echo BASE; ?>pages/about">About</a>
</li>

<li class="nav-item">
  <a class="nav-link " href="<?php echo BASE; ?>props/listing">Property Listing</a>
</li>

<li class="nav-item">
  <a class="nav-link " href="#">Why Choose Us</a>
</li>

<li class="nav-item dropdown">
  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">How to...</a>
  <div class="dropdown-menu">
    <a class="dropdown-item active" href="#">Choose the Right Property</a>
    <a class="dropdown-item active" href="#">Find the Right Agent</a>
    <a class="dropdown-item active" href="#">Buy Your Home</a>
  </div>
</li>
<li class="nav-item">
  <a class="nav-link " href="<?php echo BASE; ?>props/contact">Contact</a>
</li>
</ul>
