<div class="intro intro-carousel swiper position-relative">
    <div class="swiper-wrapper">
        <?php foreach (_j($highlights, []) as $record) {
            $i = rand(0, 4); ?>
            <div class="swiper-slide carousel-item-a intro-item bg-image" style="background-image: url(<?php echo IMG . $record['images'][$i]; ?>)">
                <div class="overlay overlay-a"></div>
                <div class="intro-content display-table">
                    <div class="table-cell">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-8">
                                    <div class="intro-body">
                                        <p class="intro-title-top">
                                            <?php echo _j($record['address']['district']) . ', ' . _j($record['address']['state']) . '<br/>' . _j($record['address']['zip']); ?>
                                        </p>
                                        <h1 class="intro-title mb-4 ">
                                            <span class="color-b"><?php echo _j($record['address']['streetNumber']) . '</span>' . _j($record['address']['streetName']); ?><br />
                                                <?php // echo _j($record['address']['district']) . ', ' . _j($record['address']['state']) . '<br/>' . _j($record['address']['zip']); 
                                                ?>
                                        </h1>
                                        <p class="intro-subtitle intro-price">
                                            <a href="<?php echo BASE; ?>props/details/<?php echo _j($record['mlsNumber']); ?>"><span class="price-a"><?php echo _j($record['type']); ?> | $ <?php echo _j($record['listPrice']) ?></span></a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
    <div class="swiper-pagination"></div>
</div><!-- End Intro Section -->


<section class="container">

    <div id="marketing" class="container-fluid">


        <div class="row">
<?php foreach ($cprop as $city=>$cpr) { $list = json_decode(_j($cpr), true);
?>
            <div class="col-lg-4">
                <h2>
                <img src="<?= BASE ?>assets/img/<?= $city ?>.jpg" style="width:9rem; height:3rem;"/>
                    Properties in <?= $city ?></h2>
                <div class="row">
                    <?php $ctr=0; 
                    foreach (_j($list['listings'],[]) as $k => $record) {
//                        print_r($record); exit; 
                        $ctr++; if ($ctr > 4) break; ?>
                        <div class="col-lg-12 col-12">
        <div class="card-box-a card-shadow">
            <div class="img-box-a">
                <img src="<?php echo IMG . _j($record['images'][0]); ?>" alt="" class="img-a img-fluid">
            </div>
            <div class="card-overlay">
                <div class="card-overlay-a-content">
                    <div class="card-header-a">
                        <h2 class="card-title-a">
                            <a href="<?php echo BASE; ?>props/details/<?php echo _j($record['mlsNumber']); ?>">
                                <?php echo _j($record['address']['streetNumber']) . ' ' . _j($record['address']['streetName']); ?>
                                <br /><span><?php echo _j($record['address']['district']) . ', ' . _j($record['address']['state']) . _j($record['address']['zip']); ?></span>
                            </a>
                        </h2>
                    </div>
                    <div class="card-body-a">
                        <div class="price-box d-flex">
                            <span class="price-a"><?php echo _j($record['details']['type']); ?> | $ <?php echo _j($record['listPrice']); ?></span>
                        </div>
                        <a href="<?php echo BASE; ?>props/details/<?php echo _j($record['mlsNumber']); ?>" class="link-a">Click here to view
                            <span class="bi bi-chevron-right"></span>
                        </a>
                    </div>
                    <div class="card-footer-a">
                        <ul class="card-info d-flex justify-content-around">
                            <li>
                                <h4 class="card-info-title">Area</h4>
                                <span><?php echo (is_array(_j($record['details']['sqft'])) ? '' : _j($record['details']['sqft'])); ?>
                                    SqFt
                                </span>
                            </li>
                            <li>
                                <h4 class="card-info-title">Beds</h4>
                                <span><?php echo _j($record['details']['numBedrooms']); ?></span>
                            </li>
                            <li>
                                <h4 class="card-info-title">Baths</h4>
                                <span><?php echo _j($record['details']['numBathrooms']); ?></span>
                            </li>
                            <li>
                                <h4 class="card-info-title">Garages</h4>
                                <span><?php echo (is_array(_j($record['details']['numGarageSpaces']))) ? implode('', _j($record['details']['numGarageSpaces'])) : $record['details']['numGarageSpaces']; ?></span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>&nbsp;
                        </div>
                    <?php  } ?>
                </div>
            </div>
<?php } ?>
        </div>



        <div class="row">
            <div class="col-lg-4">
            <img src="<?= BASE ?>img/condo.jpg" style="max-width:100%;"/>
                <h2>Condo</h2>
                <div class="row">
                    <?php $ctr=0; foreach (_j($records['condo'], []) as $k => $stat) { 
                        $ctr++; if ($ctr > 8) break; ?>
                        <div class="col-lg-6 col-6">
                            <div class="small-box bg-1">
                                <div class="inner">
                                    <h3><?php echo $stat['count']; ?></h3>
                                    <p><?php echo $k; ?></p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-bag"></i>
                                </div>
                                <a href="<?php echo BASE; ?>props/listing/propertyType/<?php echo $k; ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                    <?php  } ?>
                </div>
            </div>
            <!-- /.col-lg-4 -->
            <div class="col-lg-4">
                <img src="<?= BASE ?>img/commercial.jpg" style="max-width:100%;"/>
                <h2>Commercial</h2>
                <div class="row">
                    <?php $ctr=0; foreach (_j($records['commercial'], []) as $k => $stat) {
                        $ctr++; if ($ctr > 8) break; ?>
                        <div class="col-lg-6 col-6">
                            <div class="small-box bg-2">
                                <div class="inner">
                                    <h3><?php echo $stat['count']; ?></h3>
                                    <p><?php echo $k; ?></p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-bag"></i>
                                </div>
                                <a href="<?php echo BASE; ?>props/listing/propertyType/<?php echo $k; ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                    <?php  } ?>
                </div>

            </div><!-- /.col-lg-4 -->
            <div class="col-lg-4">
            <img src="<?= BASE ?>img/residential.jpg" style="max-width:100%;"/>
                <h2>Residential</h2>
                <div class="row">
                    <?php $ctr=0; foreach (_j($records['residential'], []) as $k => $stat) {
                        $ctr++; if ($ctr > 8) break; ?>
                        <div class="col-lg-6 col-6">
                            <div class="small-box bg-3">
                                <div class="inner">
                                    <h3><?php echo $stat['count']; ?></h3>
                                    <p><?php echo $k; ?></p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-bag"></i>
                                </div>
                                <a href="<?php echo BASE; ?>props/listing/propertyType/<?php echo $k; ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                    <?php  } ?>
                </div>
            </div><!-- /.col-lg-4 -->
        </div>
    </div>

</section>