<?php
declare(strict_types=1);

/**
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link          https://cakephp.org CakePHP(tm) Project
 * @since         3.3.4
 * @license       https://opensource.org/licenses/mit-license.php MIT License
 */

namespace App\Controller;

use Cake\Event\EventInterface;

/**
 * Error Handling Controller
 *
 * Controller used by ExceptionRenderer to render error responses.
 */
class PropsController extends AppController
{
    protected $cities = [];
        /**
     * Initialization hook method.
     *
     * @return void
     */
    public function initialize(): void
    {
        $this->loadComponent('RequestHandler');
    }

    /**
     * beforeFilter callback.
     *
     * @param \Cake\Event\EventInterface $event Event.
     * @return \Cake\Http\Response|null|void
     */
    public function beforeFilter(EventInterface $event)
    {
        $this->cities = ['Toronto', 'Mississauga', 'Oakville', 'Brampton', 'Vaughan', 'Markham']; //, 'Richmond Hill'];
    }

    /**
     * beforeRender callback.
     *
     * @param \Cake\Event\EventInterface $event Event.
     * @return \Cake\Http\Response|null|void
     */
    public function beforeRender(EventInterface $event)
    {
        parent::beforeRender($event);
        //        $this->viewBuilder()->setTemplatePath('Default');
    }

    /**
     * afterFilter callback.
     *
     * @param \Cake\Event\EventInterface $event Event.
     * @return \Cake\Http\Response|null|void
     */
    public function afterFilter(EventInterface $event)
    {
    }

    public function index()
    {
        $props = $this->_sapi('listings/property-types'); // stats by prop types
        $proparr = json_decode(_j($props), true);
        $records = [];
        foreach (_j($proparr['boards'][0]['classes'], []) as $k => $proptype) {
            foreach (_j($proptype, []) as $j => $prop) {
                foreach (_j($prop[0], []) as $i => $pr) {
                //    if (! strlen(_j($pr['style'],''))) continue;
                    $records[$k][$i] = ['count' => $pr['activeCount'], 'style' => $pr['style']];
                }
            }
        }
        $this->set(compact('records'));

        $props = $this->_api('listings?page=' . rand(1,3) . '&resultsPerPage=10');
        $proparr = json_decode(_j($props), true);
        $records = $highlights = [];
        foreach (_j($proparr['listings'], []) as $k => $prop) {
                    $highlights[$k] = array_merge(_j($prop['details']),
                     [
                    'mlsNumber' => _j($prop['mlsNumber']), 
                    'class'=> _j($prop['class']),
                    'type'=> _j($prop['type']),
                    'listDate'=> _j($prop['listDate']),
                    'status'=> _j($prop['status']),
                    'lastStatus'=> _j($prop['lastStatus']),
                    'listPrice' => _j($prop['listPrice']),
                    'soldPrice' => _j($prop['soldPrice']),
                    'permissions' => _j($prop['permissions']),
                    'images'=> _j($prop['images']), 'address' => _j($prop['address']),
                    'map' => _j($prop['map']), 'lot'=> _j($prop['lot']),
                    'agent' => _j($prop['agent']),
                    'updatedOn'=> _j($prop['updatedOn']),
                    'office'=> _j($prop['office']),
                    ]);
                    $raw[$k] = $prop;
        }
        $this->set(compact('highlights'));
        foreach (_j($this->cities,[]) as $city) {
            $cprop[$city] = $this->_api('listings?page=' . rand(1,3) . '&resultsPerPage=3&city=' . $city . '&country=CA');
        }
        $this->set('cprop',_j($cprop,[]));
    }

    public function contact()
    {
    }

    public function listing($filter = 'page', $value = '1')
    {
        $props = $this->_api('listings?resultsPerPage=15&' . $filter . '=' . $value, _j($params,[]));
        $proparr = json_decode(_j($props), true);
        $records = $raw = [];
        foreach (_j($proparr['listings'], []) as $k => $prop) {
                    $records[$k] = array_merge(_j($prop['details']),
                     [
                    'mlsNumber' => _j($prop['mlsNumber']), 
                    'class'=> _j($prop['class']),
                    'type'=> _j($prop['type']),
                    'listDate'=> _j($prop['listDate']),
                    'status'=> _j($prop['status']),
                    'lastStatus'=> _j($prop['lastStatus']),
                    'listPrice' => _j($prop['listPrice']),
                    'soldPrice' => _j($prop['soldPrice']),
                    'permissions' => _j($prop['permissions']),
                    'images'=> _j($prop['images']), 'address' => _j($prop['address']),
                    'map' => _j($prop['map']), 'lot'=> _j($prop['lot']),
                    'agent' => _j($prop['agent']),
                    'updatedOn'=> _j($prop['updatedOn']),
                    'office'=> _j($prop['office']),
                    ]);
                    $raw[$k] = $prop;
        }
        $this->set(compact('records', 'raw'));
//        print_r($raw); exit;
    }

    public function details($mls = '')
    {
        $props = $this->_api('listings?mlsNumber='. $mls);
        //        $props = $this->_api('https://sandbox.repliers.io/listings/property-types'); // stats by prop types
//        print_r($props);exit;
        $proparr = json_decode(_j($props,''), true);
        $record = [];
//        print_r($proparr);exit;
        foreach (_j($proparr['listings'], []) as $k => $prop) {
            $record = array_merge(_j($prop['details']), ['mlsNumber' => _j($prop['mlsNumber']), 
            'class'=> _j($prop['class']),
            'listDate'=> _j($prop['listDate']),
            'status'=> _j($prop['status']),
            'lastStatus'=> _j($prop['lastStatus']),
            'listPrice' => _j($prop['listPrice']),
            'soldPrice' => _j($prop['soldPrice']),
            'permissions' => _j($prop['permissions']),
            'images'=> _j($prop['images']), 'address' => _j($prop['address']),
            'map' => _j($prop['map']), 'lot'=> _j($prop['lot']),
            'agent' => _j($prop['agent']),
            'updatedOn'=> _j($prop['updatedOn']),
            'office'=> _j($prop['office']),
            ]);
        }
        $this->set(compact('record'));
//        print_r(_j($proparr['listings'][0])); exit;
        $this->set('proparr', _j($proparr['listings'][0], []));
// print_r($record);
        $histjson = $this->_api('listings/history?city='. _j($record['address']['city']) . '&streetName=' . _j($record['address']['streetName']) . '&streetNumber=' . _j($record['address']['streetNumber']) . '&streetSuffix=' . _j($record['address']['streetSuffix']) );
        $hist = json_decode($histjson, true);
//        print_r($hist['history']);exit;
        $this->set('prophst', _j($hist['history'],[]));
    }


    protected function _api($url, $params=[])
    {
return $this->_sapi($url . '&state=Ontario&class=residential', $params);
    }
    protected function _sapi($url, $params=[])
    {
        $api = (TEST) ? 'REPLIERS-API-KEY: Tfh7XmxA1JQ9QXY5Xv8bXhs6DhSN8F' : 'REPLIERS-API-KEY: taecHelmCkhO5q9QdKZYFmNcCh6YeQ';
        $curl = curl_init();
        foreach (_j($params,[]) as $k=>$param) {
$where = _j($where) . '&' . $k . '=' . $param;
        }
        curl_setopt_array($curl, array(
            CURLOPT_URL => API . $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => [$api],
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        return ($response);
    }
}
